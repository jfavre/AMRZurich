#include <iostream>
#include "vtkAMAZEReader.h"

#include "vtkCamera.h"
#include "vtkCompositeDataPipeline.h"
#include "vtkDataSet.h"
#include "vtkGlyph3D.h"
#include "vtkHierarchicalDataSetGeometryFilter.h"
#include "vtkXMLHierarchicalBoxDataReader.h"
#include "vtkHierarchicalDataExtractLevel.h"
#include "vtkHierarchicalPolyDataMapper.h"
#include "vtkLODActor.h"
#include "vtkOutlineCornerFilter.h"
#include "vtkPointData.h"
#include "vtkExtractBlock.h"
#include "vtkPlane.h"
#include "vtkCutter.h"
#include "vtkPolyDataMapper.h"
#include "vtkProperty.h"
#include "vtkRenderer.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkShrinkPolyData.h"
#include "vtkSmartPointer.h"
#include "vtkSphereSource.h"
#include "vtkArrowSource.h"
#include "vtkXMLPolyDataWriter.h"
#include "vtkLookupTable.h"
#include "vtkTestUtilities.h"
#include "vtkRectilinearGrid.h"

#define VTK_CREATE(type, var) \
  vtkSmartPointer<type> var = vtkSmartPointer<type>::New(

int main(int argc, char **argv)
{

  if(argc != 2)
    {
    cerr << "Usage: TestAMAZEReader   *amr5\n"; exit(1);
    }


  vtkAMAZEReader *reader = vtkAMAZEReader::New();
  reader->SetFileName(argv[1]);
  reader->ReadMetaData();
  //cerr << *reader;
  vtkRectilinearGrid *rg;
  int dims[3];
  for(int i=0; i < reader->GetNumberOfGrids(); i++)
    {
    //rg = reader->ReadRectilinearGrid(i);
    //rg->GetDimensions(dims);
    //cerr << "dims[] = " << dims[0] << ", " << dims[1] << ", " << dims[2] << endl;
    }
  reader->Delete();
  return 0;
}
